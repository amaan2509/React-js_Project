import React from "react";
import { NavLink } from "react-router-dom";

export default function Header() {
  return (
    <div>
      <div className="top_container">
        {/* header section strats */}
        <header className="header_section">
          <div className="container">
            <nav className="navbar navbar-expand-lg custom_nav-container ">
              <NavLink className="navbar-brand" to="/Home">
                <span>Fanadesh</span>
              </NavLink>
              <button
                className="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon" />
              </button>
              <div
                className="collapse navbar-collapse"
                id="navbarSupportedContent"
              >
                <div className="d-flex ml-auto flex-column flex-lg-row align-items-center">
                  <ul className="navbar-nav  ">
                    <li className="nav-item active">
                      <NavLink className="nav-link" to="/Home">
                        {" "}
                        Home <span className="sr-only">(current)</span>
                      </NavLink>
                    </li>
                    <li className="nav-item ">
                      <NavLink className="nav-link" to="/About">
                        {" "}
                        About{" "}
                      </NavLink>
                    </li>
                    <li className="nav-item ">
                      <NavLink className="nav-link" to="/Admission">
                        {" "}
                        Admission{" "}
                      </NavLink>
                    </li>
                    <li className="nav-item ">
                      <NavLink className="nav-link" to="/Why">
                        {" "}
                        Why{" "}
                      </NavLink>
                    </li>
                    <li className="nav-item">
                      <NavLink className="nav-link" to="/Contact">
                        Contact Us
                      </NavLink>
                    </li>

                    <li className="nav-item">
                      <NavLink className="nav-link" to="/Login">
                        <button type="button" class="btn btn-primary">Sign In</button>
                      </NavLink>
                    </li>

                  </ul>
                </div>
              </div>
            </nav>
          </div>
        </header>

        
      </div>
    </div>
  );
}
