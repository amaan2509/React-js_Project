import React from 'react'
import {BrowserRouter , Routes , Route} from 'react-router-dom'
import Header from './Header'
import Home from './Home'
import About from './About'
import Contact from './Contact'
import SignUp from './SignUp'
import Footer from './Footer'
import Admission from './Admission'
import Why from './Why'
import Login from './Login'


export default function Main() {
  return (
   <BrowserRouter>
   <Routes>
    <Route index path='/' element={<> <Header/> <Home/> <Footer/> </>}></Route>
    <Route path='/Home' element={<> <Header/> <Home/> <Footer/> </>}></Route>
    <Route path='/About' element={<> <Header/> <About/> <Footer/></>}></Route>
    <Route path='/Admission' element={<> <Header/> <Admission/> <Footer/></>}></Route>
    <Route path='/Why' element={<> <Header/> <Why/> <Footer/></>}></Route>
    <Route path='/Contact' element={<> <Header/> <Contact/> <Footer/></>}></Route>
    <Route path='/SignUp' element={<> <Header/> <SignUp/> <Footer/></>}></Route>
    <Route path='/Login' element={<> <Header/> <Login/> <Footer/></>}></Route>

   </Routes>
   </BrowserRouter>
  )
}
