import axios from "axios";
import React, { useState } from "react";

export default function Contact() {

  const[contactData,setcontactData] = useState({
    id:"",
    name:"",
    email:"",
    tel:"",
    msg:""
  })


  const onHandle =(e)=>{
    setcontactData({...contactData,id:new Date().getMilliseconds().toString(), [e.target.name]:e.target.value })
    console.log(contactData)
  } 

  const sendData= async(e) =>{ 
    e.preventDefault();
    await axios.post(`http://localhost:3000/contact`, contactData)
    setcontactData({...contactData,name:"",email:"",tel:"",msg:""}
    )
  }

  return (
    <div>
      {/* contact section */}
      <section className="contact_section ">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div className="d-flex justify-content-center d-md-block">
                <h2>Contact Us</h2>
              </div>
              <form action>
                <div className="contact_form-container">
                  <div>
                    <div>
                      <input type="text" name='name' value={contactData.name} onChange={onHandle} placeholder="Name" />
                    </div>
                    <div>
                      <input type="email" name='email' value={contactData.email} onChange={onHandle} placeholder="Email" />
                    </div>
                    <div>
                      <input type="text" name='tel'value={contactData.tel} onChange={onHandle} placeholder="Phone Number" />
                    </div>
                    <div className="mt-5">
                      <input type="text" name='msg'value={contactData.msg} onChange={onHandle}  placeholder="Message" />
                    </div>
                    <div className="mt-5">
                      <button type="submit" onClick={sendData}>send</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div className="col-md-6">
              <div className="contact_img-box">
                <img src="images/students.jpg" alt />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end contact section */}
    </div>
  );
}
